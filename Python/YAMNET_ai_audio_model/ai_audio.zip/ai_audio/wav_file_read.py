import numpy as np
from scipy.io import wavfile

test_audio1 = './python/ai_audio/tiger.wav'  #path to test audio file
sample_rate1, wav_data1 = wavfile.read(test_audio1,'rb')  #Read the audio file, in binary mode
test_audio2= './python/ai_audio/miaow_16k.wav'  #path to test audio file
sample_rate2, wav_data2 = wavfile.read(test_audio2,'rb')  #Read the audio file, in binary mode

print("Shape of tiger:", wav_data1.shape)
print("Data type of waveform array:", wav_data1.dtype)
print("Sample rate:", sample_rate1)

print("Shape of miao:", wav_data2.shape)
print("Data type of waveform array:", wav_data2.dtype)
print("Sample rate:", sample_rate2)

#Reshape to mono if stereo
if len(wav_data1.shape) > 1:
    wav_data1 = wav_data1.mean(axis=1)

print("Reshaped tiger to mono:", wav_data1.shape)
