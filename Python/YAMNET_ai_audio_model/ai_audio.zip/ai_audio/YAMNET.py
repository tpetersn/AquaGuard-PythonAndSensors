
import tensorflow as tf
import tensorflow_hub as hub
import csv
from scipy.io import wavfile 
import scipy
import numpy as np


print("Code Starting from here -->", "\n")
#download the model
model = hub.load('https://tfhub.dev/google/yamnet/1')


#get the class map (labels) path
class_map_path = model.class_map_path().numpy() 

#Load and return the list of all class labels from provided CSV file path
def class_names_from_csv(class_map_csv_text):
  class_names = []
  with tf.io.gfile.GFile(class_map_csv_text) as csvfile:  # Open the CSV file with given path
    reader = csv.DictReader(csvfile)
    for row in reader:                                            # Iterate through each row in the CSV file
      class_names.append(row['display_name'])   #append the display_name column value to class_names list

  return class_names

class_map_path = model.class_map_path().numpy()
class_names = class_names_from_csv(class_map_path)  #This list contains all 521 class labels used by YAMNet



def ensure_sample_rate(original_sample_rate, waveform, desired_sample_rate=16000):
  if original_sample_rate != desired_sample_rate:
    desired_length = int(round(float(len(waveform)) * desired_sample_rate / original_sample_rate )) #recalculate the length of the waveform array
    waveform = scipy.signal.resample(waveform, desired_length)  #Resample the waveform to the desired length
  return desired_sample_rate, waveform

test_audio1 = './python/ai_audio/tiger.wav'  #path to test audio file
sample_rate, wav_data = wavfile.read(test_audio1,'rb')  #Read the audio file, in binary mode



#Reshape to mono if stereo
if len(wav_data.shape) > 1:
    wav_data = wav_data.mean(axis=1)

sample_rate, wav_data = ensure_sample_rate(sample_rate, wav_data)  #Ensure the sample rate is 16kHz


#print some info about input audio file
duration = len(wav_data) / sample_rate
print("Audio duration: {:.2f} seconds".format(duration))
print("Sample rate: {} Hz".format(sample_rate))
print("Size of waveform array:", wav_data.shape)
print("data type of waveform array:", wav_data.dtype)


#Convert the waveform to a float32 tensor and normalize to [-1.0, 1.0]
waveform = wav_data / tf.int16.max



scores, embeddings, spectrogram = model(waveform)  #Run the model, get scores, embeddings, and spectrogram

scores_np = scores.numpy()  
spectrogram_np = spectrogram.numpy()
infered_class = class_names[scores_np.mean(axis=0).argmax()]
print(f'The main sound is: {infered_class}')



